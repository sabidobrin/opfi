import './App.css';
import { Users } from './components/Users';

function App() {
    return <Users />
}

export default App;
